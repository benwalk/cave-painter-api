(function(e, a) { for(var i in a) e[i] = a[i]; }(exports, /******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 2);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports) {

module.exports = require("source-map-support/register");

/***/ }),
/* 1 */
/***/ (function(module, exports) {

module.exports = require("apollo-server-lambda");

/***/ }),
/* 2 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


__webpack_require__(0);

var _apolloServerLambda = __webpack_require__(1);

var _graphqlPlaygroundMiddlewareLambda = __webpack_require__(3);

var _graphqlPlaygroundMiddlewareLambda2 = _interopRequireDefault(_graphqlPlaygroundMiddlewareLambda);

var _schema = __webpack_require__(4);

var _resolvers = __webpack_require__(6);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var server = new _apolloServerLambda.ApolloServer({
  typeDefs: _schema.typeDefs,
  resolvers: _resolvers.resolvers,
  context: function context(_ref) {
    var event = _ref.event,
        _context = _ref.context;
    return {
      headers: event.headers,
      functionName: _context.functionName,
      event: event,
      context: _context
    };
  },
  introspection: true,
  // mocks: true,
  playground: {
    settings: {
      'editor.theme': 'light'
    }
  }
});

exports.graphqlHandler = server.createHandler({
  cors: {
    origin: true,
    credentials: true
  }
});

exports.playgroundHandler = (0, _graphqlPlaygroundMiddlewareLambda2.default)({
  endpoint: '/dev/graphql'
});

server.listen().then(function (_ref2) {
  var url = _ref2.url;

  console.log('\uD83D\uDE80 Server ready at ' + url);
});

exports.server = server;

/***/ }),
/* 3 */
/***/ (function(module, exports) {

module.exports = require("graphql-playground-middleware-lambda");

/***/ }),
/* 4 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _taggedTemplateLiteral2 = __webpack_require__(5);

var _taggedTemplateLiteral3 = _interopRequireDefault(_taggedTemplateLiteral2);

var _templateObject = (0, _taggedTemplateLiteral3.default)(['\ntype Query {\n  listOrders: [Order]!\n  listCustomers: [Customer]!\n  getOrder(id: String): Order\n\n}\n\ntype Order {\n  id: String!\n  customer: Customer!\n  lineItems: [LineItem]\n  subtotal: Float\n  discount: [Discount]\n  taxes: Float\n  shippingCost: Float\n  amount: Float\n  financialStatus: String\n  paidAt: String\n  paymentMethod: String\n  paymentReference: String\n  fulfillmentStatus: String\n  fulfilledAt: String\n  createdAt: String\n  modifiedAt: String\n  lineItemName: String\n}\n\ntype Customer {\n  id: String!\n  email: String!\n  billingAddress: Address\n  shippingAddress: Address\n}\n\ntype Address {\n  id: String\n  name: String\n  address1: String\n  address2: String\n  city: String\n  state: String\n  zip: String\n}\n\ntype LineItem {\n  name: String\n  price: Float\n  sku: String\n  variant: String\n  quantity: Int\n  requiresShipping: Boolean\n  taxable: Boolean\n  fulfillmentStatus: String\n}\n\ntype Discount {\n  id: String\n  code: String\n  amount: Float\n}\n'], ['\ntype Query {\n  listOrders: [Order]!\n  listCustomers: [Customer]!\n  getOrder(id: String): Order\n\n}\n\ntype Order {\n  id: String!\n  customer: Customer!\n  lineItems: [LineItem]\n  subtotal: Float\n  discount: [Discount]\n  taxes: Float\n  shippingCost: Float\n  amount: Float\n  financialStatus: String\n  paidAt: String\n  paymentMethod: String\n  paymentReference: String\n  fulfillmentStatus: String\n  fulfilledAt: String\n  createdAt: String\n  modifiedAt: String\n  lineItemName: String\n}\n\ntype Customer {\n  id: String!\n  email: String!\n  billingAddress: Address\n  shippingAddress: Address\n}\n\ntype Address {\n  id: String\n  name: String\n  address1: String\n  address2: String\n  city: String\n  state: String\n  zip: String\n}\n\ntype LineItem {\n  name: String\n  price: Float\n  sku: String\n  variant: String\n  quantity: Int\n  requiresShipping: Boolean\n  taxable: Boolean\n  fulfillmentStatus: String\n}\n\ntype Discount {\n  id: String\n  code: String\n  amount: Float\n}\n']);

__webpack_require__(0);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var _require = __webpack_require__(1),
    gql = _require.gql;

var typeDefs = gql(_templateObject);
module.exports = { typeDefs: typeDefs };

/***/ }),
/* 5 */
/***/ (function(module, exports) {

module.exports = require("babel-runtime/helpers/taggedTemplateLiteral");

/***/ }),
/* 6 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


__webpack_require__(0);

var _require = __webpack_require__(7),
    find = _require.find,
    filter = _require.filter;

var orders = __webpack_require__(8);

var resolvers = {
  Query: {
    listOrders: function listOrders() {
      return filter(orders, function (order) {
        return order.createdAt;
      });
    },
    listCustomers: function listCustomers() {
      return filter(orders, function (order) {
        return order.createdAt;
      });
    }
  },
  Order: {
    customer: function customer(order) {
      return find(orders, { "email": order.email, "id": order.id });
    },
    lineItems: function lineItems(order) {
      return filter(orders, { "id": order.id });
    }
  },
  Customer: {
    billingAddress: function billingAddress(customer) {
      return {
        "id": customer.id,
        "name": customer.billingName,
        "address1": customer.billingAddress1,
        "address2": customer.billingAddress2,
        "city": customer.billingCity,
        "state": customer.billingProvince,
        "zip": customer.billingZip,
        "country": customer.billingCountry,
        "phone": customer.billingPhone
      };
    },
    shippingAddress: function shippingAddress(customer) {
      return {
        "id": customer.id,
        "name": customer.shippingName,
        "address1": customer.shippingAddress1,
        "address2": customer.shippingAddress2,
        "city": customer.shippingCity,
        "state": customer.shippingProvince,
        "zip": customer.shippingZip,
        "country": customer.shippingCountry,
        "phone": customer.shippingPhone
      };
    }
  },
  LineItem: {
    name: function name(order) {
      return order.lineItemName;
    },
    price: function price(order) {
      return order.lineItemPrice;
    },
    sku: function sku(order) {
      return order.lineItemSku;
    },
    variant: function variant(order) {
      return order.lineItemVariant;
    },
    quantity: function quantity(order) {
      return order.lineItemQuantity;
    },
    requiresShipping: function requiresShipping(order) {
      return order.lineItemRequiresShipping === "TRUE";
    },
    taxable: function taxable(order) {
      return order.lineItemTaxable === "TRUE";
    },
    fulfillmentStatus: function fulfillmentStatus(order) {
      return order.lineItemFulfillmentStatus;
    }
  }
};

module.exports = { resolvers: resolvers };

/***/ }),
/* 7 */
/***/ (function(module, exports) {

module.exports = require("lodash");

/***/ }),
/* 8 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


__webpack_require__(0);

module.exports = [{
   "id": "1",
   "email": "dave.painter.coffee@gmail.com",
   "financialStatus": "PAID",
   "paidAt": "7/25/2018 21:06",
   "fulfillmentStatus": "pending",
   "fulfilledAt": "",
   "currency": "USD",
   "subtotal": "20",
   "shipping": "10",
   "taxes": "0",
   "amountRefunded": "0",
   "total": "30",
   "discountCode": "",
   "discountAmount": "0",
   "shippingMethod": "Flat rate",
   "createdAt": "7/25/2018 21:06",
   "lineItemQuantity": "1",
   "lineItemName": "Washed Colombian Coffee",
   "lineItemPrice": "10",
   "lineItemSku": "SQ0509144",
   "lineItemVariant": "200g",
   "lineItemRequiresShipping": "TRUE",
   "lineItemTaxable": "TRUE",
   "lineItemFulfillmentStatus": "pending",
   "billingName": "Dave Painter",
   "billingAddress1": "1456 Brush Blvd",
   "billingAddress2": "",
   "billingCity": "Brightenwood",
   "billingZip": "95076",
   "billingProvince": "CA",
   "billingCountry": "United States",
   "billingPhone": "",
   "shippingName": "Dave Painter",
   "shippingAddress1": "1456 Brush Blvd",
   "shippingAddress2": "",
   "shippingCity": "Brightenwood",
   "shippingZip": "95076",
   "shippingProvince": "CA",
   "shippingCountry": "United States",
   "shippingPhone": "",
   "cancelledAt": "",
   "privateNotes": "",
   "paymentMethod": "Stripe",
   "paymentReference": "ch_1Cs0jnLjGdjc8rbZ4qjuMRNp"
}, {
   "id": "1",
   "email": "",
   "financialStatus": "",
   "paidAt": "",
   "Fulfillment Status": "",
   "Fulfilled at": "",
   "currency": "",
   "subtotal": "",
   "shipping": "",
   "taxes": "",
   "amountRefunded": "",
   "total": "",
   "discountCode": "",
   "discountAmount": "",
   "shippingMethod": "",
   "createdAt": "",
   "lineItemQuantity": "1",
   "lineItemName": "Washed Ethiopian Coffee",
   "lineItemPrice": "10",
   "lineItemSku": "SQ0030016",
   "lineItemVariant": "200g",
   "lineItemRequiresShipping": "TRUE",
   "lineItemTaxable": "TRUE",
   "lineItemFulfillmentStatus": "pending",
   "billingName": "",
   "billingAddress1": "",
   "billingAddress2": "",
   "billingCity": "",
   "billingZip": "",
   "billingProvince": "",
   "billingCountry": "",
   "billingPhone": "",
   "shippingName": "",
   "shippingAddress1": "",
   "shippingAddress2": "",
   "shippingCity": "",
   "shippingZip": "",
   "shippingProvince": "",
   "shippingCountry": "",
   "shippingPhone": "",
   "cancelledAt": "",
   "privateNotes": "",
   "paymentMethod": "",
   "paymentReference": ""
}, {
   "id": "2",
   "email": "rob.boss@yahoo.com",
   "financialStatus": "refunded",
   "paidAt": "7/25/2018 22:12",
   "Fulfillment Status": "cancelled",
   "Fulfilled at": "",
   "currency": "USD",
   "subtotal": "10",
   "shipping": "10",
   "taxes": "0",
   "amountRefunded": "20",
   "total": "20",
   "discountCode": "",
   "discountAmount": "0",
   "shippingMethod": "Flat rate",
   "createdAt": "7/25/2018 22:12",
   "lineItemQuantity": "1",
   "lineItemName": "Washed Guatemalan Coffee",
   "lineItemPrice": "10",
   "lineItemSku": "SQ9095169",
   "lineItemVariant": "200g",
   "lineItemRequiresShipping": "TRUE",
   "lineItemTaxable": "TRUE",
   "lineItemFulfillmentStatus": "cancelled",
   "billingName": "Rob Boss",
   "billingAddress1": "123 Happy Tree St.",
   "billingAddress2": "",
   "billingCity": "Detroit",
   "billingZip": "97214",
   "billingProvince": "OR",
   "billingCountry": "United States",
   "billingPhone": "8583350579",
   "shippingName": "Rob Boss",
   "shippingAddress1": "123 Happy Tree St.",
   "shippingAddress2": "",
   "shippingCity": "Detroit",
   "shippingZip": "97214",
   "shippingProvince": "OR",
   "shippingCountry": "United States",
   "shippingPhone": "5552340789",
   "cancelledAt": "7/26/2018 12:32",
   "privateNotes": "",
   "paymentMethod": "Stripe",
   "paymentReference": "ch_1Cs1mILjGdjc8rbZPDKev2eP"
}, {
   "id": "3",
   "email": "cavepaintercoffee@gmail.com",
   "financialStatus": "PAID",
   "paidAt": "8/4/2018 19:26",
   "Fulfillment Status": "pending",
   "Fulfilled at": "",
   "currency": "USD",
   "subtotal": "240",
   "shipping": "0",
   "taxes": "0",
   "amountRefunded": "0",
   "total": "240",
   "discountCode": "",
   "discountAmount": "0",
   "shippingMethod": "",
   "createdAt": "8/4/2018 19:26",
   "lineItemQuantity": "1",
   "lineItemName": "3 month subscription",
   "lineItemPrice": "240",
   "lineItemSku": "SQ7673338",
   "lineItemVariant": "400g/2/Every other week",
   "lineItemRequiresShipping": "FALSE",
   "lineItemTaxable": "TRUE",
   "lineItemFulfillmentStatus": "pending",
   "billingName": "Cave Painter",
   "billingAddress1": "49 Northeast 7th Square",
   "billingAddress2": "",
   "billingCity": "Portland",
   "billingZip": "97211",
   "billingProvince": "OR",
   "billingCountry": "United States",
   "billingPhone": "",
   "shippingName": "Cave Painter",
   "shippingAddress1": "",
   "shippingAddress2": "",
   "shippingCity": "",
   "shippingZip": "",
   "shippingProvince": "",
   "shippingCountry": "",
   "shippingPhone": "",
   "cancelledAt": "",
   "privateNotes": "",
   "paymentMethod": "Stripe",
   "paymentReference": "ch_1CvbxKLjGdjc8rbZOw3r6oT0"
}, {
   "id": "4",
   "email": "cavepaintercoffee@gmail.com",
   "financialStatus": "PAID",
   "paidAt": "8/4/2018 19:28",
   "Fulfillment Status": "pending",
   "Fulfilled at": "",
   "currency": "USD",
   "subtotal": "40",
   "shipping": "10",
   "taxes": "0",
   "amountRefunded": "0",
   "total": "50",
   "discountCode": "",
   "discountAmount": "0",
   "shippingMethod": "Flat rate",
   "createdAt": "8/4/2018 19:28",
   "lineItemQuantity": "1",
   "lineItemName": "Washed Colombian Coffee",
   "lineItemPrice": "10",
   "lineItemSku": "SQ0509144",
   "lineItemVariant": "200g",
   "lineItemRequiresShipping": "TRUE",
   "lineItemTaxable": "TRUE",
   "lineItemFulfillmentStatus": "pending",
   "billingName": "cave painter",
   "billingAddress1": "49 Northeast 7th Square",
   "billingAddress2": "",
   "billingCity": "Portland",
   "billingZip": "97211",
   "billingProvince": "OR",
   "billingCountry": "United States",
   "billingPhone": "",
   "shippingName": "cave painter",
   "shippingAddress1": "49 Northeast 7th Square",
   "shippingAddress2": "",
   "shippingCity": "Portland",
   "shippingZip": "97211",
   "shippingProvince": "OR",
   "shippingCountry": "United States",
   "shippingPhone": "",
   "cancelledAt": "",
   "privateNotes": "",
   "paymentMethod": "Stripe",
   "paymentReference": "ch_1CvbyjLjGdjc8rbZKEVHb7k7"
}, {
   "id": "4",
   "email": "",
   "financialStatus": "",
   "paidAt": "",
   "Fulfillment Status": "",
   "Fulfilled at": "",
   "currency": "",
   "subtotal": "",
   "shipping": "",
   "taxes": "",
   "amountRefunded": "",
   "total": "",
   "discountCode": "",
   "discountAmount": "",
   "shippingMethod": "",
   "createdAt": "",
   "lineItemQuantity": "1",
   "lineItemName": "3 month subscription",
   "lineItemPrice": "30",
   "lineItemSku": "SQ7103073",
   "lineItemVariant": "200g/1/Monthly",
   "lineItemRequiresShipping": "FALSE",
   "lineItemTaxable": "TRUE",
   "lineItemFulfillmentStatus": "pending",
   "billingName": "",
   "billingAddress1": "",
   "billingAddress2": "",
   "billingCity": "",
   "billingZip": "",
   "billingProvince": "",
   "billingCountry": "",
   "billingPhone": "",
   "shippingName": "",
   "shippingAddress1": "",
   "shippingAddress2": "",
   "shippingCity": "",
   "shippingZip": "",
   "shippingProvince": "",
   "shippingCountry": "",
   "shippingPhone": "",
   "cancelledAt": "",
   "privateNotes": "",
   "paymentMethod": "",
   "paymentReference": ""
}];

/***/ })
/******/ ])));
//# sourceMappingURL=handler.js.map